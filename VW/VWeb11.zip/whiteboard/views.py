from django.shortcuts import render
from django.http import HttpResponse
from django.conf import settings
from django.template import loader
from .models import *
from .forms import AgendaForm, AreaForm
from django.shortcuts import redirect
import time


def before_meeting(request):
    agendas = Agenda.objects.filter(owner=request.user)
    context = {
        'agendas': agendas,
        'user_name': request.user.get_full_name()
    }
    if request.POST:
        context['areas'] = request.body

    return render(request, 'before_meeting.html', context)


def create_agenda(request):
    if request.method == 'POST':
        # create a form instance and populate it with data from the request:
        form = AgendaForm(request.POST)
        # check whether it's valid:
        if form.is_valid():
            data = form.cleaned_data
            context = {}
            request.session['current_agenda'] = {}
            request.session['current_agenda']['name'] = data['name']
            if data['area'] is not None:
                return redirect('create_select_whiteboard')
            elif data['area'] is None:
                area_form = AreaForm(request.POST)
                context['back'] = "/"
                context['form'] = area_form
                return redirect('create_area')
    else:
        form = AgendaForm()

    return render(request, 'create_agenda.html', {'form': form})


def create_area(request):
    if request.method == 'POST':
        form = AreaForm(request.POST or None)
        context = dict()
        context['back'] = "/"
        context['form'] = form
        if form.is_valid():
            new_area_data = form.cleaned_data
            area = Area(name=new_area_data['name'], owner=request.user)
            area.save()
            request.session['current_area'] = area
            return redirect('create_select_whiteboard')
    else:
        form = AreaForm(request.POST or None)

    return render(request, 'create_area.html', {'form': form})


def create_select_whiteboard(request):



    agenda = Agenda(name=data['name'], area=data['area'], owner=data['owner'])

