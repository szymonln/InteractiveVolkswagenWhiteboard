from django.apps import AppConfig


class WhiteboardConfig(AppConfig):
    name = 'whiteboard'
