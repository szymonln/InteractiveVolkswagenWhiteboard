from django.contrib import admin
from .models import *
# Register your models here.

admin.site.register(Area)
admin.site.register(Whiteboard)
admin.site.register(File)
admin.site.register(Agenda)
admin.site.register(Report)